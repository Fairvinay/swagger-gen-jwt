package com.planner.demo;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.springframework.test.context.ActiveProfiles;
import org.springframework.util.Assert;

import com.planner.demo.service.InvitationService;

@ActiveProfiles("test")
class TestInvitationService {

	@InjectMocks
	InvitationService ts;
	
	@Test
	void test() {
		 Assert.isNull(ts, "Service In Un Available " );
		
		//fail("Not yet implemented");
	}

}
