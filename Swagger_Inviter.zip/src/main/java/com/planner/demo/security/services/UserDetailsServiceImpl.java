package com.planner.demo.security.services;

import java.sql.Date;
import java.time.LocalDateTime;
import java.util.Objects;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.stereotype.Service;

import com.planner.demo.entity.Account;
import com.planner.demo.entity.Role;
import com.planner.demo.exception.AccountException;
import com.planner.demo.model.User;
import com.planner.demo.repository.RoleRepository;

@Service
public class UserDetailsServiceImpl implements UserDetailsService {

	@Autowired 
	RoleRepository  roleRepository;
	
	@Override
	public UserDetails loadUserByUsername(String username) throws UsernameNotFoundException {
		
		   
		return null;
	}
	public UserDetails loadUserByUser(String username , String password) throws UsernameNotFoundException {
		
		/* User user = userRepository.findByUsername(username)
			        .orElseThrow(() -> new UsernameNotFoundException("User Not Found with username: " + username));*/
		return null;
	}
	public Role getRoles( User ts) throws AccountException {
		 
		if(  Objects.nonNull(ts) ) { 
			
			  Long userHash = (long) (ts.getUsername() + ts.getPassword() ).hashCode() ;
			  //Long password  =(long)  .hashCode();
			  
			  Account newAccount = new Account( 0L , userHash , new Date(LocalDateTime.now().getNano()));
			  
			  Optional<Role> r =  roleRepository.findById(newAccount.getAccountId() );
			 
					  		  
			 return r.get();
			 }
		  else {
			  throw new AccountException("Account details missmatch ");
		  }
	}

}
