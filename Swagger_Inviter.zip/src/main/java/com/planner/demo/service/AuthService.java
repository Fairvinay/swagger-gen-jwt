package com.planner.demo.service;

import java.security.Key;
import java.sql.Date;
import java.time.LocalDateTime;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.function.Function;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

import com.planner.demo.entity.Account;
import com.planner.demo.entity.Order;
import com.planner.demo.exception.AccountException;
import com.planner.demo.exception.InvitationException;
import com.planner.demo.model.Token;
import com.planner.demo.model.TokenImpl;
import com.planner.demo.model.User;
import com.planner.demo.repository.AccountRepository;
import com.planner.demo.repository.OrderRepository;
import com.planner.demo.repository.RoleRepository;
import com.planner.demo.util.JWTUtil;

import io.jsonwebtoken.Claims;
import io.jsonwebtoken.Jwts;
import io.jsonwebtoken.SignatureAlgorithm;
import io.jsonwebtoken.io.Decoders;
import io.jsonwebtoken.security.Keys;

@Service
public class AuthService {
	
	@Autowired
	OrderRepository orderRepository; 
	
	@Autowired 
	AccountRepository  accountRepository;
	
	@Autowired 
	RoleRepository  roleRepository;
	
	@Value("${security.jwt.secret-key}")
    private String secretKey;

    @Value("${security.jwt.expiration-time}")
    private long jwtExpiration;
	
	public boolean hasInvite(Account ts) throws InvitationException {
			
		if(  Objects.nonNull(ts) ) { 
			
			 // Find all by Id the Order > 10 
			List<Order> isMoreThan10 = orderRepository.findAllById(List.of(ts.getAccountId()));
			
			  return isMoreThan10.size() == 10;
		  }
		  else {
			  throw new InvitationException("No InvitePossible ");
		  }
 	}
	

	public String getAccessToken( User ts) throws AccountException {
		 
		if(  Objects.nonNull(ts) ) { 
			
			  Long userHash = (long) (ts.getUsername() + ts.getPassword() ).hashCode() ;
			  //Long password  =(long)  ts.getPassword().hashCode();
			  
			  Account newAccount = new Account( 0L , userHash , new Date(LocalDateTime.now().getNano()));
			  
			  accountRepository.save(newAccount);
			  JWTUtil.setCred(jwtExpiration,secretKey);
			  
			  Token tk = new TokenImpl (JWTUtil.generateToken(ts));
					  		  
			 return  tk.getAccessToken();
		  }
		  else {
			  throw new AccountException("Account details missmatch ");
		  }
	}


	public void deleteByUserId(Long userId) {
		 
		
	}

	
}
