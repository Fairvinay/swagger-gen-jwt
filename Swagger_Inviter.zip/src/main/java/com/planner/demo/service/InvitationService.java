package com.planner.demo.service;

import java.util.Objects;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.planner.demo.entity.Invitation;
import com.planner.demo.exception.InvitationException;
import com.planner.demo.repository.InvitationRepository;

@Service
public class InvitationService {
  
	
	@Autowired
	InvitationRepository trans; 
	
	public Invitation createInvitation(Invitation ts) throws InvitationException {
		  
		  if(  Objects.nonNull(ts) ) { 
			  
			  return trans.save(ts);
		  }
		  else {
			  throw new InvitationException();
		  }
	}

	public Invitation updateInvitation(Invitation ts) throws InvitationException {
		 
		if(  Objects.nonNull(ts) ) { 
			  Long id = ts.getInviteId();
			   boolean isIndb  =   trans.findByInviteId(id) !=null ? true: false;
			   if( isIndb) {
				   return  trans.saveAndFlush(ts);
			   }
			   else {
				   return null;
			   }
		  }
		  else {
			  throw new InvitationException();
		  }
	}

	@SuppressWarnings("deprecation")
	public Invitation getInvitation(Long id ) throws InvitationException {
	 
		if(  Objects.nonNull(id) ) { 
			   
			  
			   if( trans.findByInviteId(id) !=null) {
			    Invitation td= 	    trans.findByInviteId(id)  ;
			     return td;
				    
			   }
			   else {
				   return null;
			   }
		  }
		  else {
			  throw new InvitationException("NOTFOUND");
		  }
	}
}
