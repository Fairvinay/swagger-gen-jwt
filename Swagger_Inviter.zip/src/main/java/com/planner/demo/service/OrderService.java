package com.planner.demo.service;

import java.util.Objects;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.planner.demo.entity.Order;
import com.planner.demo.exception.OrderException;
import com.planner.demo.repository.OrderRepository;

@Service
public class OrderService {
	
	@Autowired
	OrderRepository orderRepository; 
	
	public Order createOrder(Order ts) throws OrderException {
			
		if(  Objects.nonNull(ts) ) { 
			  return orderRepository.save(ts);
			  
		  }
		  else {
			  throw new OrderException();
		  }
 	}
	

	public Order updateOrder(Order ts) throws OrderException {
		 
		if(  Objects.nonNull(ts) ) { 
			  Long id = ts.getOrderId();
			   boolean isIndb  =   orderRepository.findByOrderId(id) !=null ? true: false;
			   if( isIndb) {
				   return  orderRepository.saveAndFlush(ts);
			   }
			   else {
				   return null;
			   }
		  }
		  else {
			  throw new OrderException();
		  }
	}

	@SuppressWarnings("deprecation")
	public Order getOrder(Long id ) throws OrderException {
	 
		if(  Objects.nonNull(id) ) { 
			   
			  
			   if( orderRepository.findByOrderId(id) !=null) {
				   Order td= orderRepository.findByOrderId(id)  ;
			     return td;
				    
			   }
			   else {
				   return null;
			   }
		  }
		  else {
			  throw new OrderException("NOTFOUND");
		  }
	}
	
	

}
