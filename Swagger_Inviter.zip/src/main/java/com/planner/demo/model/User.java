package com.planner.demo.model;

import java.sql.Date;
import java.util.ArrayList;
import java.util.Collection;
import java.util.List;

import org.springframework.security.core.GrantedAuthority;
import org.springframework.security.core.userdetails.UserDetails;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@AllArgsConstructor
@Setter
@Getter
@NoArgsConstructor
public class User  implements UserDetails {
	Long id;
	String email;
	String  userName;
	String  password;
	 
	
	@Override
	public Collection<? extends GrantedAuthority> getAuthorities() {
		List<GrantedAuthority> g = new ArrayList<>();
		
		return  g;
	}
	@Override
	public String getUsername() {
		 
		return userName;
	}
	
}
