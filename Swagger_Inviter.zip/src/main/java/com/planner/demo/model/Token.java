package com.planner.demo.model;

public interface Token {
    
	 String getAccessToken();
	 
	 String getRefreshToken();
	 
}
