package com.planner.demo.model;

public class TokenImpl implements Token {
	
	String accessToken;
	String refreshToken;
	
	public TokenImpl(String generateToken) {
		// TODO Auto-generated constructor stub
		accessToken = generateToken;
	}

	@Override
	public String getAccessToken() {
		// TODO Auto-generated method stub
		return accessToken;
	}

	@Override
	public String getRefreshToken() {
		// TODO Auto-generated method stub
		return refreshToken;
	}

}
