package com.planner.demo.entity;

import java.sql.Date;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Table;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Entity
@Data
@AllArgsConstructor
@Setter
@Getter
@NoArgsConstructor
@Table(name="SubAccount")

public class SubAccount   {
	@Id
	@GeneratedValue(strategy = GenerationType.SEQUENCE)
    @Column(name="ID", unique=true, nullable=false, precision=20)
	Long id;	
	
	 @Column(name="ACCOUNT_ID", length=15) 
		Long accountId;
	 @Column(name="SUB_ACCOUNT_ID", length=15) 
	Long subAccountId;
	 @Column(name="STATUS", length=15) 
	Boolean status;
    
}
