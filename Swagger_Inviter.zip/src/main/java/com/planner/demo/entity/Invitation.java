package com.planner.demo.entity;

import java.io.Serializable;
import java.sql.Date;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Table;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Entity
@Data
@AllArgsConstructor
@Setter
@Getter
@NoArgsConstructor
@Table(name="Invitation")

public class Invitation implements Serializable {
	
	private static final long serialVersionUID = -2147468513335906679L;
	
	@Id
	@GeneratedValue(strategy = GenerationType.SEQUENCE)
    @Column(name="ID", unique=true, nullable=false, precision=20)
	Long id;
	
	 @Column(name="INVITE_ID", length=10)
	Long inviteId;
	 
	 @Column(name="INVITE_TOKEN", length=300)
	String inviteToken;
	 
	 @Column(name="INVITED_TO_ACCOUNT", length=15) 
	Long  invitedAccount; 
	 @Column(name="INVITED_FROM_ACCOUNT", length=15) 
	Long  fromAccount;
	 @Column(name="DATE", precision=4) 
	Date inviteDate;
	 @Column(name="EXPIRY_DATE", precision=4) 
	Date inviteExpiryDate;

}
