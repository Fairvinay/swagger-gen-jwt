package com.planner.demo.entity;

import java.sql.Date;
import java.time.LocalDateTime;

public interface OrderInterface {
    Long orderId =  (long) Math.round(20) * 100;
    Long accountId = (long) Math.round(15) * 100;
    Date orderDate  =  new Date( LocalDateTime.now().getNano());
    
	Long getOrderId();
    Date getOrderDate();
	Long getAccountId();
	
}
