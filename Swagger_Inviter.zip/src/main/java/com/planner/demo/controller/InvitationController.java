package com.planner.demo.controller;

import java.util.Arrays;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.stream.Collectors;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.planner.demo.entity.Invitation;
import com.planner.demo.exception.InvitationException;
import com.planner.demo.service.InvitationService;

import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.responses.ApiResponses;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import io.swagger.v3.oas.annotations.media.Content;
import io.swagger.v3.oas.annotations.media.Schema;
import io.swagger.v3.oas.annotations.tags.Tag;


@CrossOrigin(origins = "*", maxAge = 3600)
@Tag(name = "Invitation", description = "Invitation management APIs")
@RestController

public class InvitationController {
    
	private static final Logger logger = LoggerFactory.getLogger(InvitationController.class);
	    
	@Autowired
	InvitationService inviteservice;
	
	@PostMapping(path="/create", consumes={"application/json"})
	public ResponseEntity<Object> createInvitation(@RequestBody  Invitation ts) throws InvitationException {
		
		logger.info("Request  Invitation  "+ts.toString());
		Invitation tt=    inviteservice.createInvitation(ts);
		
		if(Objects.nonNull(tt)) {
			logger.info("Invitation  CREATED  ");
			 return  ResponseEntity.ok(tt);
		}
		else {
			logger.info("Invitation  FAILED CREATION  ");
			return  ResponseEntity.internalServerError().build();
		}
	}
	@PutMapping("/put")
	public ResponseEntity<Object> putInvitation(@RequestBody  Invitation ts) throws InvitationException {
		
			
		Invitation tt=    inviteservice.updateInvitation(ts);
		if(Objects.nonNull(tt)) {
			logger.info("Invitation  UPDATED ");
			 return  ResponseEntity.ok(tt);
		}
		else {
			logger.info("Invitation  FAILED UPDATE ");
			return  ResponseEntity.notFound().build();
		}
	}
	@Operation(summary = "Get a invitation by id", description = "Returns a invitation as per the id")
	@ApiResponses(value = {
	        @ApiResponse(responseCode = "200", description = "Successfully retrieved"), 
	        @ApiResponse(responseCode = "404", description = "Not found - The inviation was not found")
	    })
	@GetMapping("/get/{id}")
	public ResponseEntity<Object> getInvitation(@PathVariable ( value = "id", required=true  ) String id ) throws InvitationException {
		
		logger.info("Request  Invitation ID  "+ id);
		
		 
		 if(Objects.nonNull(id)) {
			 
			Invitation tt=    inviteservice.getInvitation(Long.parseLong(id ));
			if(Objects.nonNull(tt)) {
				logger.info("Invitation  FOUDN ");
				 return  ResponseEntity.ok(tt);
			}
			else {
				logger.info("Invitation  FETCH FAILED ");
				return  ResponseEntity.badRequest().build();
			}
		 }
		 else {
				logger.info("Invitation MISSING ID or NULL  ");
				return  ResponseEntity.badRequest().build();
		  }
	}
	
	@Operation(summary = "Exception Handled ", description = "Describes the exceptional responses handled ")
	@ApiResponses(value = { 
			  @ApiResponse(responseCode = "200", description = "Found the Invitation", 
			    content = { @Content(mediaType = "application/json", 
			      schema = @Schema(implementation =Invitation.class)) }),
			  @ApiResponse(responseCode = "400", description = "Invalid Request for Invitation supplied", 
			    content = @Content),
			  @ApiResponse(responseCode = "403", description = "Invalid Request forbidden", 
			    content = @Content),
			  @ApiResponse(responseCode = "404", description = "Invitation not found", 
			    content = @Content),
			  @ApiResponse(responseCode = "500", description = "Server is in problem", 
			    content = @Content)
	})
	
	@ExceptionHandler(value = InvitationException.class)
	public ResponseEntity handleException (Exception e) {
		logger.info("Invitation ISSUE  "+e.getMessage());
		ResponseEntity temp =  ResponseEntity.ok().build();
		
		  switch( e.getMessage()) {
		  
		  case "NULL" : 
			  			temp =    ResponseEntity.badRequest().build();
			  			break;
		  case "NOTFOUND"	  			
		  					: temp =  ResponseEntity.notFound().build();
		  				break;
		  case "ERROR"	  			
		  		 	  : temp =   ResponseEntity.internalServerError().build();
		  		 	   break;
		  		 	   
		  }
		  
		 return temp; 

	}
	
}
