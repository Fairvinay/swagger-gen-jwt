package com.planner.demo.controller;

import java.util.Arrays;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.stream.Collectors;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.planner.demo.entity.Order;
import com.planner.demo.exception.OrderException;
import com.planner.demo.model.User;
import com.planner.demo.service.OrderService;

import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.media.Content;
import io.swagger.v3.oas.annotations.media.Schema;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import io.swagger.v3.oas.annotations.responses.ApiResponses;
import io.swagger.v3.oas.annotations.tags.Tag;

@CrossOrigin(origins = "*", maxAge = 3600)
@Tag(name = "Order", description = "Order management APIs")
@RestController

public class OrderController {
    
	private static final Logger logger = LoggerFactory.getLogger(OrderController.class);
	    
	@Autowired
	OrderService orderservice;
	
	@Operation(summary = "User Order Placed ", description = "Returns the Order placed  ")
	@ApiResponses(value = {
			@ApiResponse(responseCode = "200", description = "Order Valid ", 
				    content = { @Content(mediaType = "application/json", 
				      schema = @Schema(implementation =Order.class)) }), 
	        @ApiResponse(responseCode = "404", description = "Order place failed ")
	    })
	
	@PostMapping(path="/placeorder", consumes={"application/json"})
	public ResponseEntity<Object> createOrder(@RequestBody  Order ts) throws OrderException {
		
		logger.info("Request  Order  "+ts.toString());
		Order tt=    orderservice.createOrder(ts);
		
		if(Objects.nonNull(tt)) {
			logger.info("Order  CREATED  ");
			 return  ResponseEntity.ok(tt);
		}
		else {
			logger.info("Order  FAILED CREATION  ");
			return  ResponseEntity.internalServerError().build();
		}
	}
	@Operation(summary = "User Order Modification ", description = "Returns the Modified Order  ")
	@ApiResponses(value = {
			@ApiResponse(responseCode = "200", description = "Order Valid ", 
				    content = { @Content(mediaType = "application/json", 
				      schema = @Schema(implementation =Order.class)) }), 
	        @ApiResponse(responseCode = "404", description = "Order modify failed ")
	    })
	@PutMapping("/modifyorder")
	public ResponseEntity<Object> putOrder(@RequestBody  Order ts) throws OrderException {
		
			
		Order tt=    orderservice.updateOrder(ts);
		if(Objects.nonNull(tt)) {
			logger.info("Order  UPDATED ");
			 return  ResponseEntity.ok(tt);
		}
		else {
			logger.info("Order  FAILED UPDATE ");
			return  ResponseEntity.notFound().build();
		}
	}
	 @Operation(summary = "Exception Handled ", description = "Describes the exceptional responses handled ")
		@ApiResponses(value = { 
				  @ApiResponse(responseCode = "200", description = "Found the Order", 
				    content = { @Content(mediaType = "application/json", 
				      schema = @Schema(implementation =Order.class)) }),
				  @ApiResponse(responseCode = "400", description = "Invalid Request for Order supplied", 
				    content = @Content),
				  @ApiResponse(responseCode = "403", description = "Invalid Request forbidden", 
				    content = @Content),
				  @ApiResponse(responseCode = "404", description = "Order not found", 
				    content = @Content),
				  @ApiResponse(responseCode = "500", description = "Server is in problem", 
				    content = @Content)
		}) 	
	@GetMapping("/getorder/{id}")
	public ResponseEntity<Object> getOrder(@PathVariable(value = "id") String id ) throws OrderException {
		
		logger.info("Request  Order ID  "+ id);
		
		 
		 if(Objects.nonNull(id)) {
			 
			Order tt=    orderservice.getOrder(Long.parseLong(id ));
			if(Objects.nonNull(tt)) {
				logger.info("Order  FOUDN ");
				 return  ResponseEntity.ok(tt);
			}
			else {
				logger.info("Order  FETCH FAILED ");
				return  ResponseEntity.badRequest().build();
			}
		 }
		 else {
				logger.info("Order MISSING ID or NULL  ");
				return  ResponseEntity.badRequest().build();
		  }
	}
	
	
	@ExceptionHandler(value = OrderException.class)
	public ResponseEntity handleException (Exception e) {
		logger.info("Order ISSUE  "+e.getMessage());
		ResponseEntity temp =  ResponseEntity.ok().build();
		
		  switch( e.getMessage()) {
		  
		  case "NULL" : 
			  			temp =    ResponseEntity.badRequest().build();
			  			break;
		  case "NOTFOUND"	  			
		  					: temp =  ResponseEntity.notFound().build();
		  				break;
		  case "ERROR"	  			
		  		 	  : temp =   ResponseEntity.internalServerError().build();
		  		 	   break;
		  		 	   
		  }
		  
		 return temp; 
		
		
		
	}
	
}
