package com.planner.demo.controller;

import java.util.Arrays;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.stream.Collectors;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.planner.demo.entity.Invitation;
import com.planner.demo.entity.Order;
import com.planner.demo.exception.AccountException;
import com.planner.demo.exception.OrderException;
import com.planner.demo.model.User;
import com.planner.demo.security.services.UserDetailsImpl;
import com.planner.demo.service.AuthService;
import com.planner.demo.service.OrderService;

import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.media.Content;
import io.swagger.v3.oas.annotations.media.Schema;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import io.swagger.v3.oas.annotations.responses.ApiResponses;
import io.swagger.v3.oas.annotations.tags.Tag;

@CrossOrigin(origins = "*", maxAge = 3600)
@Tag(name = "Login", description = "Authentication management APIs")
@RestController
@RequestMapping("/api/auth")
public class LoginController {
    
	private static final Logger logger = LoggerFactory.getLogger(LoginController.class);
	    
	@Autowired
	OrderService orderService;
	@Autowired
	AuthService authService;
	
	@Operation(summary = "Sigin User ", description = "Returns the Authenticated User Access ")
	@ApiResponses(value = {
	        @ApiResponse(responseCode = "200", description = "Successfully retrieved"), 
	        @ApiResponse(responseCode = "404", description = "User not Authorised ")
	    })
	 
	@PostMapping(path="/signin", consumes={"application/json"})
	public ResponseEntity<Object> loginUser(@RequestBody  User ts) throws OrderException, AccountException {
		
		logger.info("Request  USer  "+ts.toString());
		 String tt=    authService.getAccessToken(ts) ;
				    
		
		if(Objects.nonNull(tt)) {
			logger.info("USer Authentication  ");
			 return  ResponseEntity.ok(tt);
		}
		else {
			logger.info("USer Login  FAILED CREATION  ");
			return  ResponseEntity.internalServerError().build();
		}
	}
	 
	 @PostMapping("/signout")
	  public ResponseEntity<?> logoutUser() {
	    UserDetailsImpl userDetails = (UserDetailsImpl) SecurityContextHolder.getContext().getAuthentication().getPrincipal();
	    Long userId = userDetails.getId();
	    // authService.deleteByUserId(userId);
	    final HttpHeaders responseHeaders = new HttpHeaders();
	    responseHeaders.set("JWT_TOKEN", "");
	    final ResponseEntity<?> response = new ResponseEntity<>(responseHeaders, HttpStatus.FORBIDDEN);
	    
	    return response.ok( "Log out successful!" );
	  }
	 
	 @Operation(summary = "Exception Handled ", description = "Describes the exceptional responses handled ")
		@ApiResponses(value = { 
				  @ApiResponse(responseCode = "200", description = "Found the Refresh", 
				    content = { @Content(mediaType = "application/json", 
				      schema = @Schema(implementation =User.class)) }),
				  @ApiResponse(responseCode = "400", description = "Invalid Request for Refresh supplied", 
				    content = @Content),
				  @ApiResponse(responseCode = "403", description = "Invalid Request forbidden", 
				    content = @Content),
				  @ApiResponse(responseCode = "404", description = "User not found", 
				    content = @Content),
				  @ApiResponse(responseCode = "500", description = "Server is in problem", 
				    content = @Content)
		}) 	
	@GetMapping("/retry")
	public ResponseEntity<Object> getRefresh(@RequestBody  User ts ) throws OrderException, AccountException {
		
		 
		 if(Objects.nonNull(ts)) {
			logger.info("Request  userName  "+ ts.getUsername());
				
				
			String tt=    authService.getAccessToken(ts) ;
			if(Objects.nonNull(tt)) {
				logger.info("User  FOUDN ");
				 return  ResponseEntity.ok(tt);
			}
			else {
				logger.info("User FETCH FAILED ");
				return  ResponseEntity.badRequest().build();
			}
		 }
		 else {
				logger.info("User MISSING ID or NULL  ");
				return  ResponseEntity.badRequest().build();
		  }
	}
	
	
	@ExceptionHandler(value = { OrderException.class , AccountException.class} )
	public ResponseEntity handleException (Exception e) {
		logger.info("Order ISSUE  "+e.getMessage());
		ResponseEntity temp =  ResponseEntity.ok().build();
		
		  switch( e.getMessage()) {
		  
		  case "NULL" : 
			  			temp =    ResponseEntity.badRequest().build();
			  			break;
		  case "NOTFOUND"	  			
		  					: temp =  ResponseEntity.notFound().build();
		  				break;
		  case "ERROR"	  			
		  		 	  : temp =   ResponseEntity.internalServerError().build();
		  		 	   break;
		  		 	   
		  }
		  
		 return temp; 
		
		
		
	}
	
}
