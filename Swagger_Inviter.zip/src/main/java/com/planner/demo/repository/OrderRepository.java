package com.planner.demo.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.planner.demo.entity.Invitation;
import com.planner.demo.entity.Order;
import com.planner.demo.entity.Order;

@Repository
public interface OrderRepository extends JpaRepository<Order ,Long>  {
   
	public Order findByOrderId(Long id);
	
	 
}
