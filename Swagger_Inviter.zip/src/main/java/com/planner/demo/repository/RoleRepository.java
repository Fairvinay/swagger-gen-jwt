package com.planner.demo.repository;

import org.springframework.data.jpa.repository.JpaRepository;

 
import com.planner.demo.entity.Role;

public interface RoleRepository extends JpaRepository<Role ,Long>  {
	   
		public Role findByAccountId(Long id);
		

}
