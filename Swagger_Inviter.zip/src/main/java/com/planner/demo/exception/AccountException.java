package com.planner.demo.exception;

public class AccountException extends Exception {
   
	public AccountException() { 
		super();
		
		
	}
	public AccountException(String mssg) { 
		super(mssg);
		
		
	}
}
