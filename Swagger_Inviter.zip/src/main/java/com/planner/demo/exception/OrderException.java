package com.planner.demo.exception;

public class OrderException extends Exception {
	
	public OrderException() { 
		super();
    }
	public OrderException(String mssg) { 
		super(mssg);
 	
	}
}
