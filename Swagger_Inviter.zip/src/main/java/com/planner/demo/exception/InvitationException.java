package com.planner.demo.exception;

public class InvitationException extends Exception{
   
	public InvitationException() { 
		super();
		
		
	}
	public InvitationException(String mssg) { 
		super(mssg);
		
		
	}
}
