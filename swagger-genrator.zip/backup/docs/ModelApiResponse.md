

# ModelApiResponse

Describes the result of uploading an image resource

## Properties

| Name | Type | Description | Notes |
|------------ | ------------- | ------------- | -------------|
|**code** | **Integer** |  |  [optional] |
|**type** | **String** |  |  [optional] |
|**message** | **String** |  |  [optional] |



